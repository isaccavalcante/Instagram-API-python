pip install pyopenssl ndg-httpsclient pyasn1
apt-get install libffi-dev libssl-dev
